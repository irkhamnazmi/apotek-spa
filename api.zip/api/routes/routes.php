<?php
ob_start(); // 
// Jika OPTIONS (preflight request)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', trim($path, '/'));

// filter semua elemen kosong ("" atau null)
$uri = array_values(array_filter($uri, fn($v) => $v !== ''));

// ambil paling terakhir yang valid
$table = end($uri);



function parseInput()
{
    $raw = file_get_contents("php://input");

    // Jika JSON
    if (!empty($raw)) {
        $json = json_decode($raw, true);
        if ($json !== null) return $json;
    }

    // Jika form-data biasa
    return $_POST;
}

// ====================== SATUAN ======================




// ====================== SATUAN ======================
if ($table === 'satuan') {
    require_once __DIR__ . "/../controllers/SatuanController.php";
    $c = new SatuanController();
    if ($method === 'GET') isset($_GET['id_satuan']) ? $c->show($_GET['id_satuan']) : $c->index();
    elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_satuan'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_satuan']);
    }
} elseif ($table === 'dashboard') {
    require_once __DIR__ . "/../controllers/DashboardController.php";
    $c = new DashboardController();
    $c->index(parseInput());
} elseif ($table === 'login') {
    require_once __DIR__ . "/../controllers/LoginController.php";
    $c = new LoginController();

    if ($method === 'POST') {
        $input = parseInput();  // JSON / form-data
        $c->login($input);
    }
}



// ====================== MASTER_BARANG ======================
elseif ($table === 'master_barang') {
    require_once __DIR__ . "/../controllers/MasterBarangController.php";
    $c = new MasterBarangController();
    if ($method === 'GET') isset($_GET['id_barang']) ? $c->show($_GET['id_barang']) : $c->index();
    elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_barang'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_barang']);
    }
}

// ====================== USERS ======================
elseif ($table === 'users') {
    require_once __DIR__ . "/../controllers/UsersController.php";
    $c = new UsersController();
    if ($method === 'GET') isset($_GET['id_user']) ? $c->show($_GET['id_user']) : $c->index();
    elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_user'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_user']);
    }
}

// ====================== JENIS_PEMBAYARAN ======================
elseif ($table === 'jenis_pembayaran') {
    require_once __DIR__ . "/../controllers/JenisPembayaranController.php";
    $c = new JenisPembayaranController();
    if ($method === 'GET') isset($_GET['id_jenis_pembayaran']) ? $c->show($_GET['id_jenis_pembayaran']) : $c->index();
    elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_jenis_pembayaran'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_jenis_pembayaran']);
    }
}

// ====================== LOKASI_PENYIMPANAN ======================
elseif ($table === 'lokasi_penyimpanan') {
    require_once __DIR__ . "/../controllers/LokasiPenyimpananController.php";
    $c = new LokasiPenyimpananController();
    if ($method === 'GET') isset($_GET['id_lokasi_penyimpanan']) ? $c->show($_GET['id_lokasi_penyimpanan']) : $c->index();
    elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_lokasi_penyimpanan'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_lokasi_penyimpanan']);
    }
}

// ====================== STOK_OPNAME ======================
elseif ($table === 'stok_opname') {
    require_once __DIR__ . "/../controllers/StokOpnameController.php";
    $c = new StokOpnameController();
    if ($method === 'GET') {
        if (isset($_GET['startDate']) && isset($_GET['endDate'])) {
            // Jika ada, panggil fungsi untuk menampilkan laporan berdasarkan rentang tanggal
            $startDate = $_GET['startDate'];
            $endDate = $_GET['endDate'];
            $c->showByDateRange($startDate, $endDate);  // Fungsi untuk menampilkan data berdasarkan tanggal
        } elseif (isset($_GET['id_stok_opname'])) {
            $c->show($_GET['id_stok_opname']);
        } else {
            $c->index();
        }
    } elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_stok_opname'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_stok_opname']);
    }
}



// ====================== KASIR_DETAIL ======================
elseif ($table === 'kasir_detail') {
    require_once __DIR__ . "/../controllers/KasirDetailController.php";
    $c = new KasirDetailController();
    if ($method === 'GET') isset($_GET['id_kasir_detail']) ? $c->show($_GET['id_kasir_detail']) : $c->index();
    elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_kasir_detail'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_kasir_detail']);
    }
}

// ====================== KASIR ======================
elseif ($table === 'kasir') {
    require_once __DIR__ . "/../controllers/KasirController.php";
    $c = new KasirController();
    if ($method === 'GET') {
        if (isset($_GET['tgl_awal']) && isset($_GET['tgl_akhir'])) {
            // Jika ada, panggil fungsi untuk menampilkan laporan berdasarkan rentang tanggal
            $tglAwal = $_GET['tgl_awal'];
            $tglAkhir = $_GET['tgl_akhir'];
            $c->showByDateRange($tglAwal, $tglAkhir);  // Fungsi untuk menampilkan data berdasarkan tanggal
        }
        if (!empty($_GET['id_kasir'])) {
            $c->show($_GET['id_kasir']);
        } else {
            $c->index();
        }
    } elseif ($method === 'POST') $c->store(parseInput());
    elseif ($method === 'PUT') $c->update(parseInput()['id_kasir'], parseInput());
    elseif ($method === 'DELETE') {
        parse_str(file_get_contents("php://input"), $input);
        $c->destroy($input['id_kasir']);
    }
}

// ====================== DEFAULT ======================
else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "Endpoint tidak ditemukan"]);
}
